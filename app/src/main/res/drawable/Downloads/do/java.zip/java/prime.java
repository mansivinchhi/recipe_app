class prime
{
	public static void main(String arg[])
	{
		int start=5,end=15,flag=0;
			for(int j=start;j<=end;j++)
			{
				flag=0;
				for(int i=2;i<j;i++)
				{
					if(j%i==0)
						{
							
							
							flag++;
							break;
						}
						
				}			
				if(flag==0)
				{
					System.out.println(j+"is Prime number");
					
					
				}
					
			}		
	}
}