import java.util.*;
class emp
{


	emp()
	{
		System.out.println("unknown");
	}
	emp(String n)
	{
		System.out.println("name is:"+n);
	}
	
	public static void main(String args[])
	{
		String nm;
		Scanner sc=new Scanner(System.in);
		emp e=new emp();
		System.out.println("Enter the name");
		nm=sc.next();
		emp e1=new emp(nm);
		
		
	}
}