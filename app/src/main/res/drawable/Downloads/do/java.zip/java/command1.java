class command1
{
	
		public static void main(String args[])
		{
			System.out.println("First name is " +args[0]);
			System.out.println("Second  name is " +args[1]);
			System.out.println("third name is " +args[2]);
		}
}