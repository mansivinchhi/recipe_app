class test
{
	int a;
	
	test(int i)
	{
		a=i;
	}
	void swap(test t2)
	{
		int temp;
		temp=t2.a;
		t2.a=a;
		a=temp;
		
	}
	public static void main(String args[])
	{
		
		
		test t1=new test(10);
		test t2=new test(20);
		System.out.println("befor swap:"+t1.a+" "+t2.a);
		
		t1.swap(t2);
		System.out.println("after swap:"+t1.a+" "+t2.a);
		
	}
	
}