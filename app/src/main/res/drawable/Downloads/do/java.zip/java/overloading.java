class overloading
{
	int id;
	String name;
	int age;
	
	overloading(int i,String n)
	{
		id=i;
		name=n;
		
	}
	overloading(int i,String n,int a)
	{
		id=i;
		name=n;
		age=a;
	}
	void display()
	{
		System.out.println(id+" "+name+" "+age);
	}
	int add(int a,int b)
	{
		System.out.println("a+b="+(a+b));
		return 0;
	}
	int add(int x,int y,int z)
	{
	
		System.out.println("x+y+z="+(x+y+z));
		return 0;
	}
	public static void main(String arg[])
	{
		overloading o=new overloading(1,"a");	
		overloading o1=new overloading(2,"Aa",18);
		o.add(10,20);
		o.add(10,20,30);
		o.display();
		o1.display();
	}
}
