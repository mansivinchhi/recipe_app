import java.util.*;
class arm
{
		public static void main(String arg[])
		{
			int n,temp,t,t1=1,sum=0;
			System.out.println("Enter  the number:");
			Scanner sc=new Scanner(System.in);
			n=sc.nextInt();
			temp=n;
			while(n>0)
			{
				t=n%10;
				
				sum=sum+(t*t*t);
				n=n/10;
			}
				if(sum==temp)
				{
					System.out.println("This is armstrong number");
				}
				else
				{
					System.out.println("This is not armstrong number");
				}
		}
}