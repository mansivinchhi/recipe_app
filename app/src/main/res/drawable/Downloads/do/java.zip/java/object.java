import java.util.*;
class Student
{
	int r_no,marks;
	String name;
	void display()
	{
			System.out.println("Roll no is:"+r_no);
		System.out.println("name is:"+name);
		System.out.println("name is:"+marks);
	}
	public static void main(String arg[])
	{
		Scanner sc=new Scanner(System.in);
		Student s=new Student();
		Student s1=new Student();
		
		System.out.println("Enter First student detail:");
		
		System.out.println("Enter the rollno:");
		s.r_no=sc.nextInt();
		System.out.println("Enter the name:");
		s.name=sc.next();
		System.out.println("Enter the Marks:");
		s.marks=sc.nextInt();
		
		
		System.out.println("Enter Second student detail:");
		System.out.println("Enter the rollno:");
		s1.r_no=sc.nextInt();
		System.out.println("Enter the name:");
		s1.name=sc.next();
		System.out.println("Enter the Marks:");
		s1.marks=sc.nextInt();
		
		System.out.println();
		System.out.println("First student detail is:");
		s.display();	
		
		System.out.println();
		System.out.println("Second student detail is:");
		s1.display();
	}
	
}