import java.util.*;
class matrix
{
	public static void main(String args[])
	{
		int row,col,sumrow=0,sumcol=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no. of row:");
		row=sc.nextInt();
		System.out.println("Enter the no. of columns:");
		col=sc.nextInt();
		System.out.println("Enter the element of matrix:");
		int a[][]=new int[row][col];
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				a[i][j]=sc.nextInt();
				 
			}
			
		}
		
		System.out.println("Element of the matrix: ");   
		
		for(int i=0;i<row;i++)
		{		
			for(int j=0;j<col;j++)
			{
				System.out.print(a[i][j] + " ");  

			}

			System.out.println(); 
			
		}
		for(int i=0;i<row;i++)
		{		sumrow=0;
			for(int j=0;j<col;j++)
			{

				sumrow=sumrow+a[i][j];
			}

			
			System.out.println("sum of "+(i+1 )+" row  is " +sumrow);
		}
		for(int i=0;i<row;i++)
		{		sumcol=0;
			for(int j=0;j<col;j++)
			{

				sumcol=sumcol+a[j][i];
			}

			
			System.out.println("sum of "+(i+1 )+" column  is " +sumcol);
		}
	}
}