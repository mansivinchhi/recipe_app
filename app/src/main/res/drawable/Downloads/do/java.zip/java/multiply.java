import java.util.*;
class matrix
{
	public static void main(String args[])
	{
		int r1=2,c1=3;
		int r2=3,c2=2;
		
		int[][] Fmatrix={{3,-2,5},{3,0,4}};
		int[][] Smatrix={{2,3},{-9,0},{0,4}};
		
		int[][] c=new int[r1][c2];
		for(int i=0;i<r1;i++)
		{
			for(int j=0;j<c2;j++)
			{
				for(int k=0;k<c1;k++)
				{
					c[i][j]+=Fmatrix[i][k]*Smatrix[k][j];
				}
				// System.out.println(c[i][j]+ " ");
			}
			
		}
		for(int i=0;i<r1;i++)
		{		
			for(int j=0;j<c2;j++)
			{
				System.out.print(c[i][j] + " ");  

			}

			System.out.println(); 
			
		}
		
		
	}
}