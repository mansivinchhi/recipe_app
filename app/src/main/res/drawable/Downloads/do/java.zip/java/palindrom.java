import java.util.*;
class palindrom
{
		public static void main(String arg[])
		{
			int n,temp,t,t1=0;
			System.out.println("Enter  the number:");
			Scanner sc=new Scanner(System.in);
			n=sc.nextInt();
			temp=n;
			while(n>0)
			{
			t=n%10;

			
				t1=(t1*10)+t;
			

				n=n/10;
			}
				if(t1==temp)
				{
					System.out.println("This is palindrom number");
				}
				else
				{
					System.out.println("This is not palindrom number");
				}
		
			
			
		}
}