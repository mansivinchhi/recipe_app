import java.util.*;
class minimum
{
	public static void main(String arg[])
	{
		int a,b,c;
		System.out.println("Enter the any three number:");
		Scanner ob=new Scanner(System.in);
		a=ob.nextInt();
		b=ob.nextInt();
		c=ob.nextInt();
		
		if(a<b && a<c)
		{
			System.out.println("A is minimum number"+a);
		}
		else if(b<a && b<c)
		{
			System.out.println("B is minimum number"+b);
		}
		else
		{
			System.out.println("C is minimum number"+c);
		}
	}
}