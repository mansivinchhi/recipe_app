class power
{
	public static void main(String args[])
	{
		int x=5,n=3,temp=1;
		for(int i=1;i<=n;i++)
		{
			temp=temp*x;
		}
		System.out.println("Power is:"+temp);
	}
}