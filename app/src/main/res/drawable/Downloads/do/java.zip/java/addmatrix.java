import java.util.*;
class addmatrix
{
	public static void main(String args[])
	{
		int row1,col1,row2,col2;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the matrix1:");
		System.out.println("Enter the no. of row of matrix1:");
		row1=sc.nextInt();
		System.out.println("Enter the no. of columns of matrix1:");
		col1=sc.nextInt();
		
		int fm[][]=new int[row1][col1];
		
		System.out.println("Enter the element of matrix1:");
		for(int i=0;i<row1;i++)
		{
			for(int j=0;j<col1;j++)
			{
				fm[i][j]=sc.nextInt();
				 
			}
			
		}
			System.out.println("Enter the matrix2:");
		System.out.println("Enter the no. of row of matrix2:");
		row2=sc.nextInt();
		System.out.println("Enter the no. of columns of matrix2:");
		col2=sc.nextInt();
		int sm[][]=new int[row2][col2];
		System.out.println("Enter the element of matrix2:");
		  
		for(int i=0;i<row2;i++)
		{
			for(int j=0;j<col2;j++)
			{
				sm[i][j]=sc.nextInt();
				 
			}
			
		}
		int r[][]=new int[row1][col1];
		for(int i=0;i<row1;i++)
		{		
			for(int j=0;j<col1;j++)
			{
				r[i][j]=fm[i][j]+sm[i][j];

			}

			
			
		}
		System.out.println("Addition of two matrix is:");
		for(int i=0;i<row1;i++)
		{		
			for(int j=0;j<col1;j++)
			{

				System.out.print(r[i][j]+" ");
			}
			System.out.println();

			
		}
	}
}