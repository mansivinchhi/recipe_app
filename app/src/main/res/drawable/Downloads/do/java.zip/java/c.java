class c
{
	public static void main(String args[])
	{
		int total=0,avg;
		for(int i=0;i<args.length;i++)
		{
			
			total=total+Integer.parseInt(args[i]);
		}
		avg=total/args.length;
		System.out.println(" "+avg);
	}
}
