import java.util.*;
class student
{
	int r_no;
	String name;
	int marks;
	
	student()
	{
		r_no=0;
		name=null;
		marks=0;
	}
	student(int r,String n,int m)
	{
		r_no=r;
		name=n;
		marks=m;
	}
	void display()
	{
		System.out.println("Roll no is:"+r_no);
		System.out.println("Roll no is:"+name);
		System.out.println("Roll no is:"+marks);
	}
	public static void main(String arg[])
	{
		int rn, mr;
		String nm;
		student s=new student();
		
		
		System.out.println();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the rollno:");
		rn = sc.nextInt();
		System.out.println("Enter the name:");
		nm =sc.next();
		System.out.println("Enter the marks:");
		mr=sc.nextInt();
		
		student s1=new student(rn,nm,mr);
		s1.display();
		
		System.out.println();
		s.display();
		
		
		
	}
}