class student
{
	int rollno;
	String name;
	int fee;
	
	public static void main(String args[])
	{
		
	}
}