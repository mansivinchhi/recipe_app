class count
{
	public static void main(String args[])
	{
		int count=0;
		for(int i=0;i<args.length;i++)
		{
			
			System.out.println(args[i]);
			
			if(args[0].charAt(i)!='\0')
				count++;
			
		}
		System.out.println(count);
	}	
}