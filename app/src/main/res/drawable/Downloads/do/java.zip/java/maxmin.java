import java.util.*;
class maxmin
{
	int  getmax(int a,int b,int c)
	{
		int d= (c>(a>b ? a:b)?c:(a>b ?a:b));
		//System.out.println("Maximum number is:"+d);
		
		return d;
	}
	int  getmin(int a,int b,int c)
	{
		int d= (c<(a<b ? a:b)?c:(a<b ?a:b));
		//System.out.println("Manimim number is:"+d);
		return d;
	}
	
	
	public static void main(String args[])
	{
		int a,b,c,d;
		maxmin m=new maxmin();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value of A:");
		a=sc.nextInt();
		System.out.println("Enter the value of B:");
		b=sc.nextInt();
		System.out.println("Enter the value of C:");
		c=sc.nextInt();
		
		
		d=m.getmax(a,b,c);
		System.out.println("Maximum number is:"+d);
		d=m.getmin(a,b,c);
		System.out.println("Manimum number is:"+d);
		
	}
}