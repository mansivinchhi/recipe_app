import java.util.*;
class account
{
	int accountno;
	double balance;
	account()
	{
		accountno=0000;
		balance=1000;
		
	}
	void check_balance(int accountno)
	{
		
		System.out.println("accountno:"+accountno);
		System.out.println("balance:"+balance);
	}
	
}
class saving extends account
{
	double interestRate;
	saving()
	{
		super();
		interestRate=.04;
	}
	void deposite(double amount)
	{
			balance=balance+(amount*interestRate);
			//System.out.println("amount is:"+balance);
	}
	void withdrow(double amount)
	{
		if(balance>=amount)
		{
			balance=balance-amount;
		}
		else
		{
			System.out.println("cannot withdrow amount"+amount);
		}
	}
	void display()
	
	{
		System.out.println("deposite:"+amount+" "+balance);
		System.out.println("balance");
	}

}
class current extends account
{
	double overdraftlimit;
	current()
	{
		overdraftlimit=1000.0;
	}
	void withdrow(double amount)
	{
		if(balance>=amount)
		{
			balance=balance-amount;
		}
		else if(overdraftlimit>=amount)
		{
			balance=balance-amount;
			overdraftlimit=overdraftlimit-(-balance);
		}
		else
		{
			System.out.println("cannot withdrow amount"+amount);
		}
	}
	void deposite(int amount)
	{
		balance=balance+amount;
	}

}
class Main
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int ano;
		double amt,wd;
		System.out.println("Enter the accountno:");
		ano=sc.nextInt();
		
		saving s=new saving();
		
			s.check_balance(ano);
		System.out.println("Enter amount to be deposite:");
		amt=sc.nextDouble();
	
		s.deposite(ano);
		System.out.println("Enter amount to be withdraw:");
		wd=sc.nextDouble();
		s.withdrow(wd);
		
	}
}
