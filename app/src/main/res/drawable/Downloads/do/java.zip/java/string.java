import java.util.*;
class string
{
		public static void main(String arg[])
		
		{
			char ch;
			int counter=0;
			
			
			
			Scanner ob=new Scanner(System.in);
			do
			{
				System.out.println("Enter the any character:");
				
				ch=ob.next().charAt(0);
			
			if(ch>='A' && ch<='Z')
			{
				ch=(char)(ch+32);
				System.out.println("Upper to lower is:"+ch);
				counter++;
				
				
			}
			else if(ch>='a' && ch<='z')
			{
				ch=(char)(ch-32);
				System.out.println("Upper to lower is:"+ch);
				counter++;
			
			
			}
			else
			{
				
				System.out.println("This is not string");
				
			}
				
			System.out.println("Counter is:"+counter);	
		}
			
			while(ch!='.');
			
			
		
			
		}
}