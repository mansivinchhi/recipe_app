class car
{
	String brand;
	car(String b)
	{
		System.out.println(b);
	}
	public String getBrand()
	{
		return brand;
	}
	
	void run()
	{
		System.out.println("Car is running,...");
	}
}
public class sample
{
	public static void main(String args[])
	{
		String str;
		car ford=new car("Ford");
		
		ford.getBrand();
		ford.brand=str;
		System.out.println("brand is:ford");
		ford.run();
	}
}
