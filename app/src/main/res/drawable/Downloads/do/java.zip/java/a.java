import java.util.*;
class a
{
		public static void main(String arg[])
		{
			int n,temp,t,t1=1,digit=0,sum=0;
			System.out.println("Enter  the number:");
			Scanner sc=new Scanner(System.in);
			n=sc.nextInt();
			temp=n;
			while(n>0)
			{
				n=n/10;
				digit++;
			}
			n=temp;
			while(n>0)
			{
				t=n%10;
				t1=1;
				for(int i=1;i<=digit;i++)
				{
					t1=t1*t;
					
				}
				sum=sum+t1;
				n=n/10;
				
			}
			
				if(sum==temp)
				{
					System.out.println("This is armstrong number");
				}
				else
				{
					System.out.println("This is not armstrong number");
				}
		}
}