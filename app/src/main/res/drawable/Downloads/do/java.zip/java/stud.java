import java.util.*;
class stud
{
	int e_no,marks;
	String name, gender;
	static 	int count=0	;
	stud()
	{
		e_no=0;
		name="null";
		gender="null";
		marks=0;
		count++;
		
	}
	stud(int eno,String g,int ms)
	{
		this();
		e_no=eno;
		//name=nm;
		gender=g;
		marks=ms;
		
	}
	
	stud(int eno,String name,String g,int m)
	{
		this(eno,g,m);
		this.name=name;
		
	}
	void display()
	{
		System.out.println("Enrollment number is:"+e_no);
		System.out.println("Name is:"+name);
		System.out.println("Gender is:"+gender);
		System.out.println("Marks is:"+marks);
		System.out.println("count is:"+count);
	}
	public static void main(String arg[])
	{
		int eno,m;
		String nm,g;
		
		Scanner sc=new Scanner(System.in);
		stud s=new stud();
		System.out.println("Enter the Enrollment Number:");
		eno=sc.nextInt();
		System.out.println("Enter the Name:");
		nm=sc.next();
		System.out.println("Enter the Gender:");
		g=sc.next();
		System.out.println("Enter the Marks:");
		m=sc.nextInt();
		
		stud s1=new stud(eno,g,m);
			//stud s3=new stud(g,m);
		stud s2=new stud(eno,nm,g,m);
		System.out.println("-------------------------");
		s.display();
		System.out.println("-------------------------");
	//	s1.display();
		System.out.println("-------------------------");
		s2.display();
	}
}