class command
{
	
		public static void main(String args[])
		{
			System.out.println("Your name is:");
			for(int i=0; i<args.length;i++)
			{
				System.out.print(args[i]);
			}
			
		}
}