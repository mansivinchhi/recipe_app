import java.util.*;
class minimum
{
	public static void main(String arg[])
	{
		int a,b,c,d;
		System.out.println("Enter the any three number:");
		Scanner ob=new Scanner(System.in);
		a=ob.nextInt();
		b=ob.nextInt();
		c=ob.nextInt();
		d=ob.nextInt();
		
		if(a>b && a>c && a>d)
		{
			System.out.println("A is maximum number"+a);
		}
		else if(b>a && b>c && b>d)
		{
			System.out.println("B is maximum number"+b);
		}
		else if(c>a && c>b && c>d)
		{
			System.out.println("C is maximum number"+c);
		}
		else
		{
			System.out.println("D is maximum number"+d);
		
			
		}
	}
}