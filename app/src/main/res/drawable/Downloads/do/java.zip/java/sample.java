class car
{
	String brand;
	car()
	{
		brand="ford";
	}
	public String getBrand()
	{
		return brand;
	}
	
	void run()
	{
		System.out.println("Car is running,...");
		System.out.println("Brand is:"+brand);
	}
}
public class sample
{
	public static void main(String args[])
	{
		String str;
		car ford=new car();
		ford.run();
		str=ford.getBrand();
		
		System.out.println("brand is:"+str);
		
	}
}
