class outer
{
	int num[];
	outer(int n[])
	{
		num=n;
	}
	void analyze()
	{
		inner i=new inner();
		System.out.println("manimum:"+i.min());
		System.out.println("maximum:"+i.max());
		System.out.println("average:"+i.avg());
		
	}
	class inner
	{
		int min()
		{
			
			return 1;
		}
		int max()
		{
			return 1;
		}
		int avg()
		{
			return 1;
		}
	}
}
class nested
{
	public static void main(String args[])
	{
		int t[]={1,2,3,4,5};
		outer o=new outer(t);
	
		o.analyze();
	}
}