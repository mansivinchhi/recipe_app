import java.util.*;
class test1
{
	static void serius(int n)
	{
		int temp=1;
		for(int i=1;i<=n;i++)
		{
			display(temp);
			temp=temp*2;
			
		}
		//return temp;
	}
	static void display(int y)
	{
		System.out.println(" "+y);
	}
	public static void main(String args[])
	{
		int n,t;
		Scanner sc=new Scanner(System.in);
		//test1 obj=new test1();
		
		n=sc.nextInt();
		serius(n);
		//display();
		
	}
	
}